const mimeTypes = require("./mime-types");
const staticFile = require("./static-file");

module.exports = {
  mimeTypes,
  staticFile,
};
